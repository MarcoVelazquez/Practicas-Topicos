﻿namespace Practica_006
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.MetodosBtt = new System.Windows.Forms.Button();
            this.TopicosBtt = new System.Windows.Forms.Button();
            this.MatrcicesOpGrpBox = new System.Windows.Forms.GroupBox();
            this.MatrizCGrpBox = new System.Windows.Forms.GroupBox();
            this.c55Txtbx = new System.Windows.Forms.TextBox();
            this.c25Txtbx = new System.Windows.Forms.TextBox();
            this.c35Txtbx = new System.Windows.Forms.TextBox();
            this.c45Txtbx = new System.Windows.Forms.TextBox();
            this.c15Txtbx = new System.Windows.Forms.TextBox();
            this.c54Txtbx = new System.Windows.Forms.TextBox();
            this.c53Txtbx = new System.Windows.Forms.TextBox();
            this.c52Txtbx = new System.Windows.Forms.TextBox();
            this.c51Txtbx = new System.Windows.Forms.TextBox();
            this.c33Txtbx = new System.Windows.Forms.TextBox();
            this.c12Txtbx = new System.Windows.Forms.TextBox();
            this.c14Txtbx = new System.Windows.Forms.TextBox();
            this.c11Txtbx = new System.Windows.Forms.TextBox();
            this.c34Txtbx = new System.Windows.Forms.TextBox();
            this.c13Txtbx = new System.Windows.Forms.TextBox();
            this.c41Txtbx = new System.Windows.Forms.TextBox();
            this.c32Txtbx = new System.Windows.Forms.TextBox();
            this.c42Txtbx = new System.Windows.Forms.TextBox();
            this.c21Txtbx = new System.Windows.Forms.TextBox();
            this.c43Txtbx = new System.Windows.Forms.TextBox();
            this.c31Txtbx = new System.Windows.Forms.TextBox();
            this.c44Txtbx = new System.Windows.Forms.TextBox();
            this.c22Txtbx = new System.Windows.Forms.TextBox();
            this.c24Txtbx = new System.Windows.Forms.TextBox();
            this.c23Txtbx = new System.Windows.Forms.TextBox();
            this.MatrizBGrpBox = new System.Windows.Forms.GroupBox();
            this.b55Txtbx = new System.Windows.Forms.TextBox();
            this.b25Txtbx = new System.Windows.Forms.TextBox();
            this.b35Txtbx = new System.Windows.Forms.TextBox();
            this.b45Txtbx = new System.Windows.Forms.TextBox();
            this.b15Txtbx = new System.Windows.Forms.TextBox();
            this.b54Txtbx = new System.Windows.Forms.TextBox();
            this.b53Txtbx = new System.Windows.Forms.TextBox();
            this.b52Txtbx = new System.Windows.Forms.TextBox();
            this.b51Txtbx = new System.Windows.Forms.TextBox();
            this.b33Txtbx = new System.Windows.Forms.TextBox();
            this.b12Txtbx = new System.Windows.Forms.TextBox();
            this.b14Txtbx = new System.Windows.Forms.TextBox();
            this.b11Txtbx = new System.Windows.Forms.TextBox();
            this.b34Txtbx = new System.Windows.Forms.TextBox();
            this.b13Txtbx = new System.Windows.Forms.TextBox();
            this.b41Txtbx = new System.Windows.Forms.TextBox();
            this.b32Txtbx = new System.Windows.Forms.TextBox();
            this.b42Txtbx = new System.Windows.Forms.TextBox();
            this.b21Txtbx = new System.Windows.Forms.TextBox();
            this.b43Txtbx = new System.Windows.Forms.TextBox();
            this.b31Txtbx = new System.Windows.Forms.TextBox();
            this.b44Txtbx = new System.Windows.Forms.TextBox();
            this.b22Txtbx = new System.Windows.Forms.TextBox();
            this.b24Txtbx = new System.Windows.Forms.TextBox();
            this.b23Txtbx = new System.Windows.Forms.TextBox();
            this.MatrizAGrpBox = new System.Windows.Forms.GroupBox();
            this.a55Txtbx = new System.Windows.Forms.TextBox();
            this.a25Txtbx = new System.Windows.Forms.TextBox();
            this.a35Txtbx = new System.Windows.Forms.TextBox();
            this.a45Txtbx = new System.Windows.Forms.TextBox();
            this.a15Txtbx = new System.Windows.Forms.TextBox();
            this.a54Txtbx = new System.Windows.Forms.TextBox();
            this.a53Txtbx = new System.Windows.Forms.TextBox();
            this.a52Txtbx = new System.Windows.Forms.TextBox();
            this.a51Txtbx = new System.Windows.Forms.TextBox();
            this.a33Txtbx = new System.Windows.Forms.TextBox();
            this.a12Txtbx = new System.Windows.Forms.TextBox();
            this.a14Txtbx = new System.Windows.Forms.TextBox();
            this.a11Txtbx = new System.Windows.Forms.TextBox();
            this.a34Txtbx = new System.Windows.Forms.TextBox();
            this.a13Txtbx = new System.Windows.Forms.TextBox();
            this.a41Txtbx = new System.Windows.Forms.TextBox();
            this.a32Txtbx = new System.Windows.Forms.TextBox();
            this.a42Txtbx = new System.Windows.Forms.TextBox();
            this.a21Txtbx = new System.Windows.Forms.TextBox();
            this.a43Txtbx = new System.Windows.Forms.TextBox();
            this.a31Txtbx = new System.Windows.Forms.TextBox();
            this.a44Txtbx = new System.Windows.Forms.TextBox();
            this.a22Txtbx = new System.Windows.Forms.TextBox();
            this.a24Txtbx = new System.Windows.Forms.TextBox();
            this.a23Txtbx = new System.Windows.Forms.TextBox();
            this.CalcularBtt = new System.Windows.Forms.Button();
            this.MatrizCLbl = new System.Windows.Forms.Label();
            this.OperacionLbl = new System.Windows.Forms.Label();
            this.TamañoLbl = new System.Windows.Forms.Label();
            this.OperacionCmBx = new System.Windows.Forms.ComboBox();
            this.TamañoCmBx = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.MetodosGrpBox = new System.Windows.Forms.GroupBox();
            this.MetodosCalcularBtt = new System.Windows.Forms.Button();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.C1Lbl = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.C3TxtBox = new System.Windows.Forms.TextBox();
            this.C2TxtBox = new System.Windows.Forms.TextBox();
            this.C1TxtBox = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.CoeficienteX2R3TxtBOx = new System.Windows.Forms.TextBox();
            this.CoeficienteX3R3TxtBOx = new System.Windows.Forms.TextBox();
            this.CoeficienteX1R3TxtBOx = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.CoeficienteX2R2TxtBOx = new System.Windows.Forms.TextBox();
            this.CoeficienteX3R2TxtBOx = new System.Windows.Forms.TextBox();
            this.CoeficienteX1R2TxtBOx = new System.Windows.Forms.TextBox();
            this.X2Lbl = new System.Windows.Forms.Label();
            this.X3Lbl = new System.Windows.Forms.Label();
            this.X1Lbl = new System.Windows.Forms.Label();
            this.CoeficienteX2R1TxtBOx = new System.Windows.Forms.TextBox();
            this.CoeficienteX3R1TxtBOx = new System.Windows.Forms.TextBox();
            this.CoeficienteX1R1TxtBOx = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.MatrcicesOpGrpBox.SuspendLayout();
            this.MatrizCGrpBox.SuspendLayout();
            this.MatrizBGrpBox.SuspendLayout();
            this.MatrizAGrpBox.SuspendLayout();
            this.MetodosGrpBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // MetodosBtt
            // 
            this.MetodosBtt.Location = new System.Drawing.Point(602, 122);
            this.MetodosBtt.Name = "MetodosBtt";
            this.MetodosBtt.Size = new System.Drawing.Size(121, 34);
            this.MetodosBtt.TabIndex = 84;
            this.MetodosBtt.Text = "Resolver sistema de ecuaciones";
            this.MetodosBtt.UseVisualStyleBackColor = true;
            this.MetodosBtt.Click += new System.EventHandler(this.MetodosBtt_Click);
            // 
            // TopicosBtt
            // 
            this.TopicosBtt.Location = new System.Drawing.Point(602, 210);
            this.TopicosBtt.Name = "TopicosBtt";
            this.TopicosBtt.Size = new System.Drawing.Size(121, 34);
            this.TopicosBtt.TabIndex = 85;
            this.TopicosBtt.Text = "Operaciones con matrices";
            this.TopicosBtt.UseVisualStyleBackColor = true;
            this.TopicosBtt.Click += new System.EventHandler(this.TopicosBtt_Click);
            // 
            // MatrcicesOpGrpBox
            // 
            this.MatrcicesOpGrpBox.Controls.Add(this.MatrizCGrpBox);
            this.MatrcicesOpGrpBox.Controls.Add(this.MatrizBGrpBox);
            this.MatrcicesOpGrpBox.Controls.Add(this.MatrizAGrpBox);
            this.MatrcicesOpGrpBox.Controls.Add(this.CalcularBtt);
            this.MatrcicesOpGrpBox.Controls.Add(this.MatrizCLbl);
            this.MatrcicesOpGrpBox.Controls.Add(this.OperacionLbl);
            this.MatrcicesOpGrpBox.Controls.Add(this.TamañoLbl);
            this.MatrcicesOpGrpBox.Controls.Add(this.OperacionCmBx);
            this.MatrcicesOpGrpBox.Controls.Add(this.TamañoCmBx);
            this.MatrcicesOpGrpBox.Controls.Add(this.label2);
            this.MatrcicesOpGrpBox.Controls.Add(this.label1);
            this.MatrcicesOpGrpBox.Location = new System.Drawing.Point(12, 12);
            this.MatrcicesOpGrpBox.Name = "MatrcicesOpGrpBox";
            this.MatrcicesOpGrpBox.Size = new System.Drawing.Size(561, 427);
            this.MatrcicesOpGrpBox.TabIndex = 86;
            this.MatrcicesOpGrpBox.TabStop = false;
            this.MatrcicesOpGrpBox.Text = "Operaciones con matrices";
            this.MatrcicesOpGrpBox.Visible = false;
            // 
            // MatrizCGrpBox
            // 
            this.MatrizCGrpBox.Controls.Add(this.c55Txtbx);
            this.MatrizCGrpBox.Controls.Add(this.c25Txtbx);
            this.MatrizCGrpBox.Controls.Add(this.c35Txtbx);
            this.MatrizCGrpBox.Controls.Add(this.c45Txtbx);
            this.MatrizCGrpBox.Controls.Add(this.c15Txtbx);
            this.MatrizCGrpBox.Controls.Add(this.c54Txtbx);
            this.MatrizCGrpBox.Controls.Add(this.c53Txtbx);
            this.MatrizCGrpBox.Controls.Add(this.c52Txtbx);
            this.MatrizCGrpBox.Controls.Add(this.c51Txtbx);
            this.MatrizCGrpBox.Controls.Add(this.c33Txtbx);
            this.MatrizCGrpBox.Controls.Add(this.c12Txtbx);
            this.MatrizCGrpBox.Controls.Add(this.c14Txtbx);
            this.MatrizCGrpBox.Controls.Add(this.c11Txtbx);
            this.MatrizCGrpBox.Controls.Add(this.c34Txtbx);
            this.MatrizCGrpBox.Controls.Add(this.c13Txtbx);
            this.MatrizCGrpBox.Controls.Add(this.c41Txtbx);
            this.MatrizCGrpBox.Controls.Add(this.c32Txtbx);
            this.MatrizCGrpBox.Controls.Add(this.c42Txtbx);
            this.MatrizCGrpBox.Controls.Add(this.c21Txtbx);
            this.MatrizCGrpBox.Controls.Add(this.c43Txtbx);
            this.MatrizCGrpBox.Controls.Add(this.c31Txtbx);
            this.MatrizCGrpBox.Controls.Add(this.c44Txtbx);
            this.MatrizCGrpBox.Controls.Add(this.c22Txtbx);
            this.MatrizCGrpBox.Controls.Add(this.c24Txtbx);
            this.MatrizCGrpBox.Controls.Add(this.c23Txtbx);
            this.MatrizCGrpBox.Location = new System.Drawing.Point(333, 195);
            this.MatrizCGrpBox.Name = "MatrizCGrpBox";
            this.MatrizCGrpBox.Size = new System.Drawing.Size(205, 133);
            this.MatrizCGrpBox.TabIndex = 86;
            this.MatrizCGrpBox.TabStop = false;
            // 
            // c55Txtbx
            // 
            this.c55Txtbx.Location = new System.Drawing.Point(164, 103);
            this.c55Txtbx.Name = "c55Txtbx";
            this.c55Txtbx.Size = new System.Drawing.Size(30, 20);
            this.c55Txtbx.TabIndex = 24;
            this.c55Txtbx.Text = "0";
            this.c55Txtbx.Visible = false;
            // 
            // c25Txtbx
            // 
            this.c25Txtbx.Location = new System.Drawing.Point(164, 28);
            this.c25Txtbx.Name = "c25Txtbx";
            this.c25Txtbx.Size = new System.Drawing.Size(30, 20);
            this.c25Txtbx.TabIndex = 9;
            this.c25Txtbx.Text = "0";
            this.c25Txtbx.Visible = false;
            // 
            // c35Txtbx
            // 
            this.c35Txtbx.Location = new System.Drawing.Point(164, 53);
            this.c35Txtbx.Name = "c35Txtbx";
            this.c35Txtbx.Size = new System.Drawing.Size(30, 20);
            this.c35Txtbx.TabIndex = 14;
            this.c35Txtbx.Text = "0";
            this.c35Txtbx.Visible = false;
            // 
            // c45Txtbx
            // 
            this.c45Txtbx.Location = new System.Drawing.Point(164, 78);
            this.c45Txtbx.Name = "c45Txtbx";
            this.c45Txtbx.Size = new System.Drawing.Size(30, 20);
            this.c45Txtbx.TabIndex = 19;
            this.c45Txtbx.Text = "0";
            this.c45Txtbx.Visible = false;
            // 
            // c15Txtbx
            // 
            this.c15Txtbx.Location = new System.Drawing.Point(164, 3);
            this.c15Txtbx.Name = "c15Txtbx";
            this.c15Txtbx.Size = new System.Drawing.Size(30, 20);
            this.c15Txtbx.TabIndex = 4;
            this.c15Txtbx.Text = "0";
            this.c15Txtbx.Visible = false;
            // 
            // c54Txtbx
            // 
            this.c54Txtbx.Location = new System.Drawing.Point(124, 103);
            this.c54Txtbx.Name = "c54Txtbx";
            this.c54Txtbx.Size = new System.Drawing.Size(30, 20);
            this.c54Txtbx.TabIndex = 23;
            this.c54Txtbx.Text = "0";
            this.c54Txtbx.Visible = false;
            // 
            // c53Txtbx
            // 
            this.c53Txtbx.Location = new System.Drawing.Point(84, 103);
            this.c53Txtbx.Name = "c53Txtbx";
            this.c53Txtbx.Size = new System.Drawing.Size(30, 20);
            this.c53Txtbx.TabIndex = 22;
            this.c53Txtbx.Text = "0";
            this.c53Txtbx.Visible = false;
            // 
            // c52Txtbx
            // 
            this.c52Txtbx.Location = new System.Drawing.Point(44, 103);
            this.c52Txtbx.Name = "c52Txtbx";
            this.c52Txtbx.Size = new System.Drawing.Size(30, 20);
            this.c52Txtbx.TabIndex = 21;
            this.c52Txtbx.Text = "0";
            this.c52Txtbx.Visible = false;
            // 
            // c51Txtbx
            // 
            this.c51Txtbx.Location = new System.Drawing.Point(4, 103);
            this.c51Txtbx.Name = "c51Txtbx";
            this.c51Txtbx.Size = new System.Drawing.Size(30, 20);
            this.c51Txtbx.TabIndex = 20;
            this.c51Txtbx.Text = "0";
            this.c51Txtbx.Visible = false;
            // 
            // c33Txtbx
            // 
            this.c33Txtbx.Location = new System.Drawing.Point(84, 53);
            this.c33Txtbx.Name = "c33Txtbx";
            this.c33Txtbx.Size = new System.Drawing.Size(30, 20);
            this.c33Txtbx.TabIndex = 12;
            this.c33Txtbx.Text = "0";
            this.c33Txtbx.Visible = false;
            // 
            // c12Txtbx
            // 
            this.c12Txtbx.Location = new System.Drawing.Point(44, 3);
            this.c12Txtbx.Name = "c12Txtbx";
            this.c12Txtbx.Size = new System.Drawing.Size(30, 20);
            this.c12Txtbx.TabIndex = 1;
            this.c12Txtbx.Text = "0";
            this.c12Txtbx.Visible = false;
            // 
            // c14Txtbx
            // 
            this.c14Txtbx.Location = new System.Drawing.Point(124, 3);
            this.c14Txtbx.Name = "c14Txtbx";
            this.c14Txtbx.Size = new System.Drawing.Size(30, 20);
            this.c14Txtbx.TabIndex = 3;
            this.c14Txtbx.Text = "0";
            this.c14Txtbx.Visible = false;
            // 
            // c11Txtbx
            // 
            this.c11Txtbx.Location = new System.Drawing.Point(4, 3);
            this.c11Txtbx.Name = "c11Txtbx";
            this.c11Txtbx.Size = new System.Drawing.Size(30, 20);
            this.c11Txtbx.TabIndex = 0;
            this.c11Txtbx.Text = "0";
            this.c11Txtbx.Visible = false;
            // 
            // c34Txtbx
            // 
            this.c34Txtbx.Location = new System.Drawing.Point(124, 53);
            this.c34Txtbx.Name = "c34Txtbx";
            this.c34Txtbx.Size = new System.Drawing.Size(30, 20);
            this.c34Txtbx.TabIndex = 13;
            this.c34Txtbx.Text = "0";
            this.c34Txtbx.Visible = false;
            // 
            // c13Txtbx
            // 
            this.c13Txtbx.Location = new System.Drawing.Point(84, 3);
            this.c13Txtbx.Name = "c13Txtbx";
            this.c13Txtbx.Size = new System.Drawing.Size(30, 20);
            this.c13Txtbx.TabIndex = 2;
            this.c13Txtbx.Text = "0";
            this.c13Txtbx.Visible = false;
            // 
            // c41Txtbx
            // 
            this.c41Txtbx.Location = new System.Drawing.Point(4, 78);
            this.c41Txtbx.Name = "c41Txtbx";
            this.c41Txtbx.Size = new System.Drawing.Size(30, 20);
            this.c41Txtbx.TabIndex = 15;
            this.c41Txtbx.Text = "0";
            this.c41Txtbx.Visible = false;
            // 
            // c32Txtbx
            // 
            this.c32Txtbx.Location = new System.Drawing.Point(44, 53);
            this.c32Txtbx.Name = "c32Txtbx";
            this.c32Txtbx.Size = new System.Drawing.Size(30, 20);
            this.c32Txtbx.TabIndex = 11;
            this.c32Txtbx.Text = "0";
            this.c32Txtbx.Visible = false;
            // 
            // c42Txtbx
            // 
            this.c42Txtbx.Location = new System.Drawing.Point(44, 78);
            this.c42Txtbx.Name = "c42Txtbx";
            this.c42Txtbx.Size = new System.Drawing.Size(30, 20);
            this.c42Txtbx.TabIndex = 16;
            this.c42Txtbx.Text = "0";
            this.c42Txtbx.Visible = false;
            // 
            // c21Txtbx
            // 
            this.c21Txtbx.Location = new System.Drawing.Point(4, 28);
            this.c21Txtbx.Name = "c21Txtbx";
            this.c21Txtbx.Size = new System.Drawing.Size(30, 20);
            this.c21Txtbx.TabIndex = 5;
            this.c21Txtbx.Text = "0";
            this.c21Txtbx.Visible = false;
            // 
            // c43Txtbx
            // 
            this.c43Txtbx.Location = new System.Drawing.Point(84, 78);
            this.c43Txtbx.Name = "c43Txtbx";
            this.c43Txtbx.Size = new System.Drawing.Size(30, 20);
            this.c43Txtbx.TabIndex = 17;
            this.c43Txtbx.Text = "0";
            this.c43Txtbx.Visible = false;
            // 
            // c31Txtbx
            // 
            this.c31Txtbx.Location = new System.Drawing.Point(4, 53);
            this.c31Txtbx.Name = "c31Txtbx";
            this.c31Txtbx.Size = new System.Drawing.Size(30, 20);
            this.c31Txtbx.TabIndex = 10;
            this.c31Txtbx.Text = "0";
            this.c31Txtbx.Visible = false;
            // 
            // c44Txtbx
            // 
            this.c44Txtbx.Location = new System.Drawing.Point(124, 78);
            this.c44Txtbx.Name = "c44Txtbx";
            this.c44Txtbx.Size = new System.Drawing.Size(30, 20);
            this.c44Txtbx.TabIndex = 18;
            this.c44Txtbx.Text = "0";
            this.c44Txtbx.Visible = false;
            // 
            // c22Txtbx
            // 
            this.c22Txtbx.Location = new System.Drawing.Point(44, 28);
            this.c22Txtbx.Name = "c22Txtbx";
            this.c22Txtbx.Size = new System.Drawing.Size(30, 20);
            this.c22Txtbx.TabIndex = 6;
            this.c22Txtbx.Text = "0";
            this.c22Txtbx.Visible = false;
            // 
            // c24Txtbx
            // 
            this.c24Txtbx.Location = new System.Drawing.Point(124, 28);
            this.c24Txtbx.Name = "c24Txtbx";
            this.c24Txtbx.Size = new System.Drawing.Size(30, 20);
            this.c24Txtbx.TabIndex = 8;
            this.c24Txtbx.Text = "0";
            this.c24Txtbx.Visible = false;
            // 
            // c23Txtbx
            // 
            this.c23Txtbx.Location = new System.Drawing.Point(84, 28);
            this.c23Txtbx.Name = "c23Txtbx";
            this.c23Txtbx.Size = new System.Drawing.Size(30, 20);
            this.c23Txtbx.TabIndex = 7;
            this.c23Txtbx.Text = "0";
            this.c23Txtbx.Visible = false;
            // 
            // MatrizBGrpBox
            // 
            this.MatrizBGrpBox.Controls.Add(this.b55Txtbx);
            this.MatrizBGrpBox.Controls.Add(this.b25Txtbx);
            this.MatrizBGrpBox.Controls.Add(this.b35Txtbx);
            this.MatrizBGrpBox.Controls.Add(this.b45Txtbx);
            this.MatrizBGrpBox.Controls.Add(this.b15Txtbx);
            this.MatrizBGrpBox.Controls.Add(this.b54Txtbx);
            this.MatrizBGrpBox.Controls.Add(this.b53Txtbx);
            this.MatrizBGrpBox.Controls.Add(this.b52Txtbx);
            this.MatrizBGrpBox.Controls.Add(this.b51Txtbx);
            this.MatrizBGrpBox.Controls.Add(this.b33Txtbx);
            this.MatrizBGrpBox.Controls.Add(this.b12Txtbx);
            this.MatrizBGrpBox.Controls.Add(this.b14Txtbx);
            this.MatrizBGrpBox.Controls.Add(this.b11Txtbx);
            this.MatrizBGrpBox.Controls.Add(this.b34Txtbx);
            this.MatrizBGrpBox.Controls.Add(this.b13Txtbx);
            this.MatrizBGrpBox.Controls.Add(this.b41Txtbx);
            this.MatrizBGrpBox.Controls.Add(this.b32Txtbx);
            this.MatrizBGrpBox.Controls.Add(this.b42Txtbx);
            this.MatrizBGrpBox.Controls.Add(this.b21Txtbx);
            this.MatrizBGrpBox.Controls.Add(this.b43Txtbx);
            this.MatrizBGrpBox.Controls.Add(this.b31Txtbx);
            this.MatrizBGrpBox.Controls.Add(this.b44Txtbx);
            this.MatrizBGrpBox.Controls.Add(this.b22Txtbx);
            this.MatrizBGrpBox.Controls.Add(this.b24Txtbx);
            this.MatrizBGrpBox.Controls.Add(this.b23Txtbx);
            this.MatrizBGrpBox.Location = new System.Drawing.Point(9, 215);
            this.MatrizBGrpBox.Name = "MatrizBGrpBox";
            this.MatrizBGrpBox.Size = new System.Drawing.Size(202, 132);
            this.MatrizBGrpBox.TabIndex = 85;
            this.MatrizBGrpBox.TabStop = false;
            // 
            // b55Txtbx
            // 
            this.b55Txtbx.Location = new System.Drawing.Point(163, 103);
            this.b55Txtbx.Name = "b55Txtbx";
            this.b55Txtbx.Size = new System.Drawing.Size(30, 20);
            this.b55Txtbx.TabIndex = 24;
            this.b55Txtbx.Text = "0";
            this.b55Txtbx.Visible = false;
            // 
            // b25Txtbx
            // 
            this.b25Txtbx.Location = new System.Drawing.Point(163, 28);
            this.b25Txtbx.Name = "b25Txtbx";
            this.b25Txtbx.Size = new System.Drawing.Size(30, 20);
            this.b25Txtbx.TabIndex = 9;
            this.b25Txtbx.Text = "0";
            this.b25Txtbx.Visible = false;
            // 
            // b35Txtbx
            // 
            this.b35Txtbx.Location = new System.Drawing.Point(163, 53);
            this.b35Txtbx.Name = "b35Txtbx";
            this.b35Txtbx.Size = new System.Drawing.Size(30, 20);
            this.b35Txtbx.TabIndex = 14;
            this.b35Txtbx.Text = "0";
            this.b35Txtbx.Visible = false;
            // 
            // b45Txtbx
            // 
            this.b45Txtbx.Location = new System.Drawing.Point(163, 78);
            this.b45Txtbx.Name = "b45Txtbx";
            this.b45Txtbx.Size = new System.Drawing.Size(30, 20);
            this.b45Txtbx.TabIndex = 19;
            this.b45Txtbx.Text = "0";
            this.b45Txtbx.Visible = false;
            // 
            // b15Txtbx
            // 
            this.b15Txtbx.Location = new System.Drawing.Point(163, 3);
            this.b15Txtbx.Name = "b15Txtbx";
            this.b15Txtbx.Size = new System.Drawing.Size(30, 20);
            this.b15Txtbx.TabIndex = 4;
            this.b15Txtbx.Text = "0";
            this.b15Txtbx.Visible = false;
            // 
            // b54Txtbx
            // 
            this.b54Txtbx.Location = new System.Drawing.Point(123, 103);
            this.b54Txtbx.Name = "b54Txtbx";
            this.b54Txtbx.Size = new System.Drawing.Size(30, 20);
            this.b54Txtbx.TabIndex = 23;
            this.b54Txtbx.Text = "0";
            this.b54Txtbx.Visible = false;
            // 
            // b53Txtbx
            // 
            this.b53Txtbx.Location = new System.Drawing.Point(83, 103);
            this.b53Txtbx.Name = "b53Txtbx";
            this.b53Txtbx.Size = new System.Drawing.Size(30, 20);
            this.b53Txtbx.TabIndex = 22;
            this.b53Txtbx.Text = "0";
            this.b53Txtbx.Visible = false;
            // 
            // b52Txtbx
            // 
            this.b52Txtbx.Location = new System.Drawing.Point(43, 103);
            this.b52Txtbx.Name = "b52Txtbx";
            this.b52Txtbx.Size = new System.Drawing.Size(30, 20);
            this.b52Txtbx.TabIndex = 21;
            this.b52Txtbx.Text = "0";
            this.b52Txtbx.Visible = false;
            // 
            // b51Txtbx
            // 
            this.b51Txtbx.Location = new System.Drawing.Point(3, 103);
            this.b51Txtbx.Name = "b51Txtbx";
            this.b51Txtbx.Size = new System.Drawing.Size(30, 20);
            this.b51Txtbx.TabIndex = 20;
            this.b51Txtbx.Text = "0";
            this.b51Txtbx.Visible = false;
            // 
            // b33Txtbx
            // 
            this.b33Txtbx.Location = new System.Drawing.Point(83, 53);
            this.b33Txtbx.Name = "b33Txtbx";
            this.b33Txtbx.Size = new System.Drawing.Size(30, 20);
            this.b33Txtbx.TabIndex = 12;
            this.b33Txtbx.Text = "0";
            this.b33Txtbx.Visible = false;
            // 
            // b12Txtbx
            // 
            this.b12Txtbx.Location = new System.Drawing.Point(43, 3);
            this.b12Txtbx.Name = "b12Txtbx";
            this.b12Txtbx.Size = new System.Drawing.Size(30, 20);
            this.b12Txtbx.TabIndex = 1;
            this.b12Txtbx.Text = "0";
            this.b12Txtbx.Visible = false;
            // 
            // b14Txtbx
            // 
            this.b14Txtbx.Location = new System.Drawing.Point(123, 3);
            this.b14Txtbx.Name = "b14Txtbx";
            this.b14Txtbx.Size = new System.Drawing.Size(30, 20);
            this.b14Txtbx.TabIndex = 3;
            this.b14Txtbx.Text = "0";
            this.b14Txtbx.Visible = false;
            // 
            // b11Txtbx
            // 
            this.b11Txtbx.Location = new System.Drawing.Point(3, 3);
            this.b11Txtbx.Name = "b11Txtbx";
            this.b11Txtbx.Size = new System.Drawing.Size(30, 20);
            this.b11Txtbx.TabIndex = 0;
            this.b11Txtbx.Text = "0";
            this.b11Txtbx.Visible = false;
            // 
            // b34Txtbx
            // 
            this.b34Txtbx.Location = new System.Drawing.Point(123, 53);
            this.b34Txtbx.Name = "b34Txtbx";
            this.b34Txtbx.Size = new System.Drawing.Size(30, 20);
            this.b34Txtbx.TabIndex = 13;
            this.b34Txtbx.Text = "0";
            this.b34Txtbx.Visible = false;
            // 
            // b13Txtbx
            // 
            this.b13Txtbx.Location = new System.Drawing.Point(83, 3);
            this.b13Txtbx.Name = "b13Txtbx";
            this.b13Txtbx.Size = new System.Drawing.Size(30, 20);
            this.b13Txtbx.TabIndex = 2;
            this.b13Txtbx.Text = "0";
            this.b13Txtbx.Visible = false;
            // 
            // b41Txtbx
            // 
            this.b41Txtbx.Location = new System.Drawing.Point(3, 78);
            this.b41Txtbx.Name = "b41Txtbx";
            this.b41Txtbx.Size = new System.Drawing.Size(30, 20);
            this.b41Txtbx.TabIndex = 15;
            this.b41Txtbx.Text = "0";
            this.b41Txtbx.Visible = false;
            // 
            // b32Txtbx
            // 
            this.b32Txtbx.Location = new System.Drawing.Point(43, 53);
            this.b32Txtbx.Name = "b32Txtbx";
            this.b32Txtbx.Size = new System.Drawing.Size(30, 20);
            this.b32Txtbx.TabIndex = 11;
            this.b32Txtbx.Text = "0";
            this.b32Txtbx.Visible = false;
            // 
            // b42Txtbx
            // 
            this.b42Txtbx.Location = new System.Drawing.Point(43, 78);
            this.b42Txtbx.Name = "b42Txtbx";
            this.b42Txtbx.Size = new System.Drawing.Size(30, 20);
            this.b42Txtbx.TabIndex = 16;
            this.b42Txtbx.Text = "0";
            this.b42Txtbx.Visible = false;
            // 
            // b21Txtbx
            // 
            this.b21Txtbx.Location = new System.Drawing.Point(3, 28);
            this.b21Txtbx.Name = "b21Txtbx";
            this.b21Txtbx.Size = new System.Drawing.Size(30, 20);
            this.b21Txtbx.TabIndex = 5;
            this.b21Txtbx.Text = "0";
            this.b21Txtbx.Visible = false;
            // 
            // b43Txtbx
            // 
            this.b43Txtbx.Location = new System.Drawing.Point(83, 78);
            this.b43Txtbx.Name = "b43Txtbx";
            this.b43Txtbx.Size = new System.Drawing.Size(30, 20);
            this.b43Txtbx.TabIndex = 17;
            this.b43Txtbx.Text = "0";
            this.b43Txtbx.Visible = false;
            // 
            // b31Txtbx
            // 
            this.b31Txtbx.Location = new System.Drawing.Point(3, 53);
            this.b31Txtbx.Name = "b31Txtbx";
            this.b31Txtbx.Size = new System.Drawing.Size(30, 20);
            this.b31Txtbx.TabIndex = 10;
            this.b31Txtbx.Text = "0";
            this.b31Txtbx.Visible = false;
            // 
            // b44Txtbx
            // 
            this.b44Txtbx.Location = new System.Drawing.Point(123, 78);
            this.b44Txtbx.Name = "b44Txtbx";
            this.b44Txtbx.Size = new System.Drawing.Size(30, 20);
            this.b44Txtbx.TabIndex = 18;
            this.b44Txtbx.Text = "0";
            this.b44Txtbx.Visible = false;
            // 
            // b22Txtbx
            // 
            this.b22Txtbx.Location = new System.Drawing.Point(43, 28);
            this.b22Txtbx.Name = "b22Txtbx";
            this.b22Txtbx.Size = new System.Drawing.Size(30, 20);
            this.b22Txtbx.TabIndex = 6;
            this.b22Txtbx.Text = "0";
            this.b22Txtbx.Visible = false;
            // 
            // b24Txtbx
            // 
            this.b24Txtbx.Location = new System.Drawing.Point(123, 28);
            this.b24Txtbx.Name = "b24Txtbx";
            this.b24Txtbx.Size = new System.Drawing.Size(30, 20);
            this.b24Txtbx.TabIndex = 8;
            this.b24Txtbx.Text = "0";
            this.b24Txtbx.Visible = false;
            // 
            // b23Txtbx
            // 
            this.b23Txtbx.Location = new System.Drawing.Point(83, 28);
            this.b23Txtbx.Name = "b23Txtbx";
            this.b23Txtbx.Size = new System.Drawing.Size(30, 20);
            this.b23Txtbx.TabIndex = 7;
            this.b23Txtbx.Text = "0";
            this.b23Txtbx.Visible = false;
            // 
            // MatrizAGrpBox
            // 
            this.MatrizAGrpBox.Controls.Add(this.a55Txtbx);
            this.MatrizAGrpBox.Controls.Add(this.a25Txtbx);
            this.MatrizAGrpBox.Controls.Add(this.a35Txtbx);
            this.MatrizAGrpBox.Controls.Add(this.a45Txtbx);
            this.MatrizAGrpBox.Controls.Add(this.a15Txtbx);
            this.MatrizAGrpBox.Controls.Add(this.a54Txtbx);
            this.MatrizAGrpBox.Controls.Add(this.a53Txtbx);
            this.MatrizAGrpBox.Controls.Add(this.a52Txtbx);
            this.MatrizAGrpBox.Controls.Add(this.a51Txtbx);
            this.MatrizAGrpBox.Controls.Add(this.a33Txtbx);
            this.MatrizAGrpBox.Controls.Add(this.a12Txtbx);
            this.MatrizAGrpBox.Controls.Add(this.a14Txtbx);
            this.MatrizAGrpBox.Controls.Add(this.a11Txtbx);
            this.MatrizAGrpBox.Controls.Add(this.a34Txtbx);
            this.MatrizAGrpBox.Controls.Add(this.a13Txtbx);
            this.MatrizAGrpBox.Controls.Add(this.a41Txtbx);
            this.MatrizAGrpBox.Controls.Add(this.a32Txtbx);
            this.MatrizAGrpBox.Controls.Add(this.a42Txtbx);
            this.MatrizAGrpBox.Controls.Add(this.a21Txtbx);
            this.MatrizAGrpBox.Controls.Add(this.a43Txtbx);
            this.MatrizAGrpBox.Controls.Add(this.a31Txtbx);
            this.MatrizAGrpBox.Controls.Add(this.a44Txtbx);
            this.MatrizAGrpBox.Controls.Add(this.a22Txtbx);
            this.MatrizAGrpBox.Controls.Add(this.a24Txtbx);
            this.MatrizAGrpBox.Controls.Add(this.a23Txtbx);
            this.MatrizAGrpBox.Location = new System.Drawing.Point(10, 44);
            this.MatrizAGrpBox.Name = "MatrizAGrpBox";
            this.MatrizAGrpBox.Size = new System.Drawing.Size(210, 131);
            this.MatrizAGrpBox.TabIndex = 84;
            this.MatrizAGrpBox.TabStop = false;
            // 
            // a55Txtbx
            // 
            this.a55Txtbx.Location = new System.Drawing.Point(162, 105);
            this.a55Txtbx.Name = "a55Txtbx";
            this.a55Txtbx.Size = new System.Drawing.Size(30, 20);
            this.a55Txtbx.TabIndex = 24;
            this.a55Txtbx.Text = "0";
            this.a55Txtbx.Visible = false;
            // 
            // a25Txtbx
            // 
            this.a25Txtbx.Location = new System.Drawing.Point(162, 30);
            this.a25Txtbx.Name = "a25Txtbx";
            this.a25Txtbx.Size = new System.Drawing.Size(30, 20);
            this.a25Txtbx.TabIndex = 9;
            this.a25Txtbx.Text = "0";
            this.a25Txtbx.Visible = false;
            // 
            // a35Txtbx
            // 
            this.a35Txtbx.Location = new System.Drawing.Point(162, 55);
            this.a35Txtbx.Name = "a35Txtbx";
            this.a35Txtbx.Size = new System.Drawing.Size(30, 20);
            this.a35Txtbx.TabIndex = 14;
            this.a35Txtbx.Text = "0";
            this.a35Txtbx.Visible = false;
            // 
            // a45Txtbx
            // 
            this.a45Txtbx.Location = new System.Drawing.Point(162, 80);
            this.a45Txtbx.Name = "a45Txtbx";
            this.a45Txtbx.Size = new System.Drawing.Size(30, 20);
            this.a45Txtbx.TabIndex = 19;
            this.a45Txtbx.Text = "0";
            this.a45Txtbx.Visible = false;
            // 
            // a15Txtbx
            // 
            this.a15Txtbx.Location = new System.Drawing.Point(162, 5);
            this.a15Txtbx.Name = "a15Txtbx";
            this.a15Txtbx.Size = new System.Drawing.Size(30, 20);
            this.a15Txtbx.TabIndex = 4;
            this.a15Txtbx.Text = "0";
            this.a15Txtbx.Visible = false;
            // 
            // a54Txtbx
            // 
            this.a54Txtbx.Location = new System.Drawing.Point(122, 105);
            this.a54Txtbx.Name = "a54Txtbx";
            this.a54Txtbx.Size = new System.Drawing.Size(30, 20);
            this.a54Txtbx.TabIndex = 23;
            this.a54Txtbx.Text = "0";
            this.a54Txtbx.Visible = false;
            // 
            // a53Txtbx
            // 
            this.a53Txtbx.Location = new System.Drawing.Point(82, 105);
            this.a53Txtbx.Name = "a53Txtbx";
            this.a53Txtbx.Size = new System.Drawing.Size(30, 20);
            this.a53Txtbx.TabIndex = 22;
            this.a53Txtbx.Text = "0";
            this.a53Txtbx.Visible = false;
            // 
            // a52Txtbx
            // 
            this.a52Txtbx.Location = new System.Drawing.Point(42, 105);
            this.a52Txtbx.Name = "a52Txtbx";
            this.a52Txtbx.Size = new System.Drawing.Size(30, 20);
            this.a52Txtbx.TabIndex = 21;
            this.a52Txtbx.Text = "0";
            this.a52Txtbx.Visible = false;
            // 
            // a51Txtbx
            // 
            this.a51Txtbx.Location = new System.Drawing.Point(2, 105);
            this.a51Txtbx.Name = "a51Txtbx";
            this.a51Txtbx.Size = new System.Drawing.Size(30, 20);
            this.a51Txtbx.TabIndex = 20;
            this.a51Txtbx.Text = "0";
            this.a51Txtbx.Visible = false;
            // 
            // a33Txtbx
            // 
            this.a33Txtbx.Location = new System.Drawing.Point(82, 55);
            this.a33Txtbx.Name = "a33Txtbx";
            this.a33Txtbx.Size = new System.Drawing.Size(30, 20);
            this.a33Txtbx.TabIndex = 12;
            this.a33Txtbx.Text = "0";
            this.a33Txtbx.Visible = false;
            // 
            // a12Txtbx
            // 
            this.a12Txtbx.Location = new System.Drawing.Point(42, 5);
            this.a12Txtbx.Name = "a12Txtbx";
            this.a12Txtbx.Size = new System.Drawing.Size(30, 20);
            this.a12Txtbx.TabIndex = 1;
            this.a12Txtbx.Text = "0";
            this.a12Txtbx.Visible = false;
            // 
            // a14Txtbx
            // 
            this.a14Txtbx.Location = new System.Drawing.Point(122, 5);
            this.a14Txtbx.Name = "a14Txtbx";
            this.a14Txtbx.Size = new System.Drawing.Size(30, 20);
            this.a14Txtbx.TabIndex = 3;
            this.a14Txtbx.Text = "0";
            this.a14Txtbx.Visible = false;
            // 
            // a11Txtbx
            // 
            this.a11Txtbx.Location = new System.Drawing.Point(2, 5);
            this.a11Txtbx.Name = "a11Txtbx";
            this.a11Txtbx.Size = new System.Drawing.Size(30, 20);
            this.a11Txtbx.TabIndex = 0;
            this.a11Txtbx.Text = "0";
            this.a11Txtbx.Visible = false;
            // 
            // a34Txtbx
            // 
            this.a34Txtbx.Location = new System.Drawing.Point(122, 55);
            this.a34Txtbx.Name = "a34Txtbx";
            this.a34Txtbx.Size = new System.Drawing.Size(30, 20);
            this.a34Txtbx.TabIndex = 13;
            this.a34Txtbx.Text = "0";
            this.a34Txtbx.Visible = false;
            // 
            // a13Txtbx
            // 
            this.a13Txtbx.Location = new System.Drawing.Point(82, 5);
            this.a13Txtbx.Name = "a13Txtbx";
            this.a13Txtbx.Size = new System.Drawing.Size(30, 20);
            this.a13Txtbx.TabIndex = 2;
            this.a13Txtbx.Text = "0";
            this.a13Txtbx.Visible = false;
            // 
            // a41Txtbx
            // 
            this.a41Txtbx.Location = new System.Drawing.Point(2, 80);
            this.a41Txtbx.Name = "a41Txtbx";
            this.a41Txtbx.Size = new System.Drawing.Size(30, 20);
            this.a41Txtbx.TabIndex = 15;
            this.a41Txtbx.Text = "0";
            this.a41Txtbx.Visible = false;
            // 
            // a32Txtbx
            // 
            this.a32Txtbx.Location = new System.Drawing.Point(42, 55);
            this.a32Txtbx.Name = "a32Txtbx";
            this.a32Txtbx.Size = new System.Drawing.Size(30, 20);
            this.a32Txtbx.TabIndex = 11;
            this.a32Txtbx.Text = "0";
            this.a32Txtbx.Visible = false;
            // 
            // a42Txtbx
            // 
            this.a42Txtbx.Location = new System.Drawing.Point(42, 80);
            this.a42Txtbx.Name = "a42Txtbx";
            this.a42Txtbx.Size = new System.Drawing.Size(30, 20);
            this.a42Txtbx.TabIndex = 16;
            this.a42Txtbx.Text = "0";
            this.a42Txtbx.Visible = false;
            // 
            // a21Txtbx
            // 
            this.a21Txtbx.Location = new System.Drawing.Point(2, 30);
            this.a21Txtbx.Name = "a21Txtbx";
            this.a21Txtbx.Size = new System.Drawing.Size(30, 20);
            this.a21Txtbx.TabIndex = 5;
            this.a21Txtbx.Text = "0";
            this.a21Txtbx.Visible = false;
            // 
            // a43Txtbx
            // 
            this.a43Txtbx.Location = new System.Drawing.Point(82, 80);
            this.a43Txtbx.Name = "a43Txtbx";
            this.a43Txtbx.Size = new System.Drawing.Size(30, 20);
            this.a43Txtbx.TabIndex = 17;
            this.a43Txtbx.Text = "0";
            this.a43Txtbx.Visible = false;
            // 
            // a31Txtbx
            // 
            this.a31Txtbx.Location = new System.Drawing.Point(2, 55);
            this.a31Txtbx.Name = "a31Txtbx";
            this.a31Txtbx.Size = new System.Drawing.Size(30, 20);
            this.a31Txtbx.TabIndex = 10;
            this.a31Txtbx.Text = "0";
            this.a31Txtbx.Visible = false;
            // 
            // a44Txtbx
            // 
            this.a44Txtbx.Location = new System.Drawing.Point(122, 80);
            this.a44Txtbx.Name = "a44Txtbx";
            this.a44Txtbx.Size = new System.Drawing.Size(30, 20);
            this.a44Txtbx.TabIndex = 18;
            this.a44Txtbx.Text = "0";
            this.a44Txtbx.Visible = false;
            // 
            // a22Txtbx
            // 
            this.a22Txtbx.Location = new System.Drawing.Point(42, 30);
            this.a22Txtbx.Name = "a22Txtbx";
            this.a22Txtbx.Size = new System.Drawing.Size(30, 20);
            this.a22Txtbx.TabIndex = 6;
            this.a22Txtbx.Text = "0";
            this.a22Txtbx.Visible = false;
            // 
            // a24Txtbx
            // 
            this.a24Txtbx.Location = new System.Drawing.Point(122, 30);
            this.a24Txtbx.Name = "a24Txtbx";
            this.a24Txtbx.Size = new System.Drawing.Size(30, 20);
            this.a24Txtbx.TabIndex = 8;
            this.a24Txtbx.Text = "0";
            this.a24Txtbx.Visible = false;
            // 
            // a23Txtbx
            // 
            this.a23Txtbx.Location = new System.Drawing.Point(82, 30);
            this.a23Txtbx.Name = "a23Txtbx";
            this.a23Txtbx.Size = new System.Drawing.Size(30, 20);
            this.a23Txtbx.TabIndex = 7;
            this.a23Txtbx.Text = "0";
            this.a23Txtbx.Visible = false;
            // 
            // CalcularBtt
            // 
            this.CalcularBtt.Location = new System.Drawing.Point(227, 328);
            this.CalcularBtt.Name = "CalcularBtt";
            this.CalcularBtt.Size = new System.Drawing.Size(110, 44);
            this.CalcularBtt.TabIndex = 83;
            this.CalcularBtt.Text = "Calcular";
            this.CalcularBtt.UseVisualStyleBackColor = true;
            this.CalcularBtt.Click += new System.EventHandler(this.CalcularBtt_Click);
            // 
            // MatrizCLbl
            // 
            this.MatrizCLbl.AutoSize = true;
            this.MatrizCLbl.Location = new System.Drawing.Point(334, 169);
            this.MatrizCLbl.Name = "MatrizCLbl";
            this.MatrizCLbl.Size = new System.Drawing.Size(102, 13);
            this.MatrizCLbl.TabIndex = 82;
            this.MatrizCLbl.Text = "Matriz C (Resultado)";
            // 
            // OperacionLbl
            // 
            this.OperacionLbl.AutoSize = true;
            this.OperacionLbl.Location = new System.Drawing.Point(311, 115);
            this.OperacionLbl.Name = "OperacionLbl";
            this.OperacionLbl.Size = new System.Drawing.Size(56, 13);
            this.OperacionLbl.TabIndex = 56;
            this.OperacionLbl.Text = "Operacion";
            // 
            // TamañoLbl
            // 
            this.TamañoLbl.AutoSize = true;
            this.TamañoLbl.Location = new System.Drawing.Point(311, 57);
            this.TamañoLbl.Name = "TamañoLbl";
            this.TamañoLbl.Size = new System.Drawing.Size(46, 13);
            this.TamañoLbl.TabIndex = 55;
            this.TamañoLbl.Text = "Tamaño";
            // 
            // OperacionCmBx
            // 
            this.OperacionCmBx.FormattingEnabled = true;
            this.OperacionCmBx.Items.AddRange(new object[] {
            "A+B",
            "A-B",
            "B-A",
            "B*A",
            "Suma de la diagonal",
            "Suma de la contra diagonal",
            "Suma por renglones",
            "Suma por columnas"});
            this.OperacionCmBx.Location = new System.Drawing.Point(383, 107);
            this.OperacionCmBx.Name = "OperacionCmBx";
            this.OperacionCmBx.Size = new System.Drawing.Size(156, 21);
            this.OperacionCmBx.TabIndex = 54;
            this.OperacionCmBx.Text = "- - -";
            // 
            // TamañoCmBx
            // 
            this.TamañoCmBx.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TamañoCmBx.FormattingEnabled = true;
            this.TamañoCmBx.Items.AddRange(new object[] {
            "2x2",
            "3x3",
            "4x4",
            "5x5"});
            this.TamañoCmBx.Location = new System.Drawing.Point(383, 49);
            this.TamañoCmBx.Name = "TamañoCmBx";
            this.TamañoCmBx.Size = new System.Drawing.Size(57, 24);
            this.TamañoCmBx.TabIndex = 53;
            this.TamañoCmBx.Text = "n x n";
            this.TamañoCmBx.SelectedIndexChanged += new System.EventHandler(this.TamañoCmBx_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(19, 198);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(45, 13);
            this.label2.TabIndex = 52;
            this.label2.Text = "Matriz B";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(19, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(45, 13);
            this.label1.TabIndex = 51;
            this.label1.Text = "Matriz A";
            // 
            // MetodosGrpBox
            // 
            this.MetodosGrpBox.Controls.Add(this.label22);
            this.MetodosGrpBox.Controls.Add(this.MetodosCalcularBtt);
            this.MetodosGrpBox.Controls.Add(this.label21);
            this.MetodosGrpBox.Controls.Add(this.label20);
            this.MetodosGrpBox.Controls.Add(this.C1Lbl);
            this.MetodosGrpBox.Controls.Add(this.label14);
            this.MetodosGrpBox.Controls.Add(this.label15);
            this.MetodosGrpBox.Controls.Add(this.label16);
            this.MetodosGrpBox.Controls.Add(this.label17);
            this.MetodosGrpBox.Controls.Add(this.label18);
            this.MetodosGrpBox.Controls.Add(this.label19);
            this.MetodosGrpBox.Controls.Add(this.label13);
            this.MetodosGrpBox.Controls.Add(this.label12);
            this.MetodosGrpBox.Controls.Add(this.label9);
            this.MetodosGrpBox.Controls.Add(this.label10);
            this.MetodosGrpBox.Controls.Add(this.label11);
            this.MetodosGrpBox.Controls.Add(this.C3TxtBox);
            this.MetodosGrpBox.Controls.Add(this.C2TxtBox);
            this.MetodosGrpBox.Controls.Add(this.C1TxtBox);
            this.MetodosGrpBox.Controls.Add(this.label6);
            this.MetodosGrpBox.Controls.Add(this.label7);
            this.MetodosGrpBox.Controls.Add(this.label8);
            this.MetodosGrpBox.Controls.Add(this.CoeficienteX2R3TxtBOx);
            this.MetodosGrpBox.Controls.Add(this.CoeficienteX3R3TxtBOx);
            this.MetodosGrpBox.Controls.Add(this.CoeficienteX1R3TxtBOx);
            this.MetodosGrpBox.Controls.Add(this.label3);
            this.MetodosGrpBox.Controls.Add(this.label4);
            this.MetodosGrpBox.Controls.Add(this.label5);
            this.MetodosGrpBox.Controls.Add(this.CoeficienteX2R2TxtBOx);
            this.MetodosGrpBox.Controls.Add(this.CoeficienteX3R2TxtBOx);
            this.MetodosGrpBox.Controls.Add(this.CoeficienteX1R2TxtBOx);
            this.MetodosGrpBox.Controls.Add(this.X2Lbl);
            this.MetodosGrpBox.Controls.Add(this.X3Lbl);
            this.MetodosGrpBox.Controls.Add(this.X1Lbl);
            this.MetodosGrpBox.Controls.Add(this.CoeficienteX2R1TxtBOx);
            this.MetodosGrpBox.Controls.Add(this.CoeficienteX3R1TxtBOx);
            this.MetodosGrpBox.Controls.Add(this.CoeficienteX1R1TxtBOx);
            this.MetodosGrpBox.Location = new System.Drawing.Point(14, 14);
            this.MetodosGrpBox.Name = "MetodosGrpBox";
            this.MetodosGrpBox.Size = new System.Drawing.Size(561, 427);
            this.MetodosGrpBox.TabIndex = 87;
            this.MetodosGrpBox.TabStop = false;
            this.MetodosGrpBox.Text = "s";
            this.MetodosGrpBox.Visible = false;
            this.MetodosGrpBox.Enter += new System.EventHandler(this.MetodosGrpBox_Enter);
            // 
            // MetodosCalcularBtt
            // 
            this.MetodosCalcularBtt.Location = new System.Drawing.Point(332, 208);
            this.MetodosCalcularBtt.Name = "MetodosCalcularBtt";
            this.MetodosCalcularBtt.Size = new System.Drawing.Size(123, 38);
            this.MetodosCalcularBtt.TabIndex = 35;
            this.MetodosCalcularBtt.Text = "Calcular";
            this.MetodosCalcularBtt.UseVisualStyleBackColor = true;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(148, 288);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(16, 13);
            this.label21.TabIndex = 34;
            this.label21.Text = "---";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(148, 314);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(16, 13);
            this.label20.TabIndex = 33;
            this.label20.Text = "---";
            this.label20.Click += new System.EventHandler(this.label20_Click);
            // 
            // C1Lbl
            // 
            this.C1Lbl.AutoSize = true;
            this.C1Lbl.Location = new System.Drawing.Point(148, 263);
            this.C1Lbl.Name = "C1Lbl";
            this.C1Lbl.Size = new System.Drawing.Size(16, 13);
            this.C1Lbl.TabIndex = 32;
            this.C1Lbl.Text = "---";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(117, 314);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(13, 13);
            this.label14.TabIndex = 31;
            this.label14.Text = "=";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(117, 288);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(13, 13);
            this.label15.TabIndex = 30;
            this.label15.Text = "=";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(117, 263);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(13, 13);
            this.label16.TabIndex = 29;
            this.label16.Text = "=";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(86, 314);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(20, 13);
            this.label17.TabIndex = 28;
            this.label17.Text = "C3";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(86, 288);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(20, 13);
            this.label18.TabIndex = 27;
            this.label18.Text = "C2";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(86, 263);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(20, 13);
            this.label19.TabIndex = 26;
            this.label19.Text = "C1";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(64, 224);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(60, 13);
            this.label13.TabIndex = 25;
            this.label13.Text = "Resultados";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(64, 66);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(166, 13);
            this.label12.TabIndex = 24;
            this.label12.Text = "Sistema de ecuaciones a resolver";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(206, 157);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(13, 13);
            this.label9.TabIndex = 23;
            this.label9.Text = "=";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(206, 131);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(13, 13);
            this.label10.TabIndex = 22;
            this.label10.Text = "=";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(206, 106);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(13, 13);
            this.label11.TabIndex = 21;
            this.label11.Text = "=";
            // 
            // C3TxtBox
            // 
            this.C3TxtBox.Location = new System.Drawing.Point(225, 154);
            this.C3TxtBox.Name = "C3TxtBox";
            this.C3TxtBox.Size = new System.Drawing.Size(20, 20);
            this.C3TxtBox.TabIndex = 20;
            // 
            // C2TxtBox
            // 
            this.C2TxtBox.Location = new System.Drawing.Point(225, 128);
            this.C2TxtBox.Name = "C2TxtBox";
            this.C2TxtBox.Size = new System.Drawing.Size(20, 20);
            this.C2TxtBox.TabIndex = 19;
            // 
            // C1TxtBox
            // 
            this.C1TxtBox.Location = new System.Drawing.Point(225, 103);
            this.C1TxtBox.Name = "C1TxtBox";
            this.C1TxtBox.Size = new System.Drawing.Size(20, 20);
            this.C1TxtBox.TabIndex = 18;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(130, 157);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(20, 13);
            this.label6.TabIndex = 17;
            this.label6.Text = "X2";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(175, 157);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(20, 13);
            this.label7.TabIndex = 16;
            this.label7.Text = "X3";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(85, 157);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(20, 13);
            this.label8.TabIndex = 15;
            this.label8.Text = "X1";
            // 
            // CoeficienteX2R3TxtBOx
            // 
            this.CoeficienteX2R3TxtBOx.Location = new System.Drawing.Point(110, 154);
            this.CoeficienteX2R3TxtBOx.Name = "CoeficienteX2R3TxtBOx";
            this.CoeficienteX2R3TxtBOx.Size = new System.Drawing.Size(20, 20);
            this.CoeficienteX2R3TxtBOx.TabIndex = 14;
            // 
            // CoeficienteX3R3TxtBOx
            // 
            this.CoeficienteX3R3TxtBOx.Location = new System.Drawing.Point(155, 154);
            this.CoeficienteX3R3TxtBOx.Name = "CoeficienteX3R3TxtBOx";
            this.CoeficienteX3R3TxtBOx.Size = new System.Drawing.Size(20, 20);
            this.CoeficienteX3R3TxtBOx.TabIndex = 13;
            // 
            // CoeficienteX1R3TxtBOx
            // 
            this.CoeficienteX1R3TxtBOx.Location = new System.Drawing.Point(65, 154);
            this.CoeficienteX1R3TxtBOx.Name = "CoeficienteX1R3TxtBOx";
            this.CoeficienteX1R3TxtBOx.Size = new System.Drawing.Size(20, 20);
            this.CoeficienteX1R3TxtBOx.TabIndex = 12;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(130, 131);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(20, 13);
            this.label3.TabIndex = 11;
            this.label3.Text = "X2";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(175, 131);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(20, 13);
            this.label4.TabIndex = 10;
            this.label4.Text = "X3";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(85, 131);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(20, 13);
            this.label5.TabIndex = 9;
            this.label5.Text = "X1";
            // 
            // CoeficienteX2R2TxtBOx
            // 
            this.CoeficienteX2R2TxtBOx.Location = new System.Drawing.Point(110, 128);
            this.CoeficienteX2R2TxtBOx.Name = "CoeficienteX2R2TxtBOx";
            this.CoeficienteX2R2TxtBOx.Size = new System.Drawing.Size(20, 20);
            this.CoeficienteX2R2TxtBOx.TabIndex = 8;
            // 
            // CoeficienteX3R2TxtBOx
            // 
            this.CoeficienteX3R2TxtBOx.Location = new System.Drawing.Point(155, 128);
            this.CoeficienteX3R2TxtBOx.Name = "CoeficienteX3R2TxtBOx";
            this.CoeficienteX3R2TxtBOx.Size = new System.Drawing.Size(20, 20);
            this.CoeficienteX3R2TxtBOx.TabIndex = 7;
            // 
            // CoeficienteX1R2TxtBOx
            // 
            this.CoeficienteX1R2TxtBOx.Location = new System.Drawing.Point(65, 128);
            this.CoeficienteX1R2TxtBOx.Name = "CoeficienteX1R2TxtBOx";
            this.CoeficienteX1R2TxtBOx.Size = new System.Drawing.Size(20, 20);
            this.CoeficienteX1R2TxtBOx.TabIndex = 6;
            // 
            // X2Lbl
            // 
            this.X2Lbl.AutoSize = true;
            this.X2Lbl.Location = new System.Drawing.Point(130, 106);
            this.X2Lbl.Name = "X2Lbl";
            this.X2Lbl.Size = new System.Drawing.Size(20, 13);
            this.X2Lbl.TabIndex = 5;
            this.X2Lbl.Text = "X2";
            // 
            // X3Lbl
            // 
            this.X3Lbl.AutoSize = true;
            this.X3Lbl.Location = new System.Drawing.Point(175, 106);
            this.X3Lbl.Name = "X3Lbl";
            this.X3Lbl.Size = new System.Drawing.Size(20, 13);
            this.X3Lbl.TabIndex = 4;
            this.X3Lbl.Text = "X3";
            // 
            // X1Lbl
            // 
            this.X1Lbl.AutoSize = true;
            this.X1Lbl.Location = new System.Drawing.Point(85, 106);
            this.X1Lbl.Name = "X1Lbl";
            this.X1Lbl.Size = new System.Drawing.Size(20, 13);
            this.X1Lbl.TabIndex = 3;
            this.X1Lbl.Text = "X1";
            // 
            // CoeficienteX2R1TxtBOx
            // 
            this.CoeficienteX2R1TxtBOx.Location = new System.Drawing.Point(110, 103);
            this.CoeficienteX2R1TxtBOx.Name = "CoeficienteX2R1TxtBOx";
            this.CoeficienteX2R1TxtBOx.Size = new System.Drawing.Size(20, 20);
            this.CoeficienteX2R1TxtBOx.TabIndex = 2;
            // 
            // CoeficienteX3R1TxtBOx
            // 
            this.CoeficienteX3R1TxtBOx.Location = new System.Drawing.Point(155, 103);
            this.CoeficienteX3R1TxtBOx.Name = "CoeficienteX3R1TxtBOx";
            this.CoeficienteX3R1TxtBOx.Size = new System.Drawing.Size(20, 20);
            this.CoeficienteX3R1TxtBOx.TabIndex = 1;
            // 
            // CoeficienteX1R1TxtBOx
            // 
            this.CoeficienteX1R1TxtBOx.Location = new System.Drawing.Point(65, 103);
            this.CoeficienteX1R1TxtBOx.Name = "CoeficienteX1R1TxtBOx";
            this.CoeficienteX1R1TxtBOx.Size = new System.Drawing.Size(20, 20);
            this.CoeficienteX1R1TxtBOx.TabIndex = 0;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(289, 122);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(145, 13);
            this.label22.TabIndex = 36;
            this.label22.Text = "¡ESTO NO FUNCIONA AÚN!";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(753, 482);
            this.Controls.Add(this.MetodosBtt);
            this.Controls.Add(this.TopicosBtt);
            this.Controls.Add(this.MatrcicesOpGrpBox);
            this.Controls.Add(this.MetodosGrpBox);
            this.Name = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.MatrcicesOpGrpBox.ResumeLayout(false);
            this.MatrcicesOpGrpBox.PerformLayout();
            this.MatrizCGrpBox.ResumeLayout(false);
            this.MatrizCGrpBox.PerformLayout();
            this.MatrizBGrpBox.ResumeLayout(false);
            this.MatrizBGrpBox.PerformLayout();
            this.MatrizAGrpBox.ResumeLayout(false);
            this.MatrizAGrpBox.PerformLayout();
            this.MetodosGrpBox.ResumeLayout(false);
            this.MetodosGrpBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button MetodosBtt;
        private System.Windows.Forms.Button TopicosBtt;
        private System.Windows.Forms.GroupBox MatrcicesOpGrpBox;
        private System.Windows.Forms.Button CalcularBtt;
        private System.Windows.Forms.Label MatrizCLbl;
        private System.Windows.Forms.TextBox c55Txtbx;
        private System.Windows.Forms.TextBox c25Txtbx;
        private System.Windows.Forms.TextBox c35Txtbx;
        private System.Windows.Forms.TextBox c45Txtbx;
        private System.Windows.Forms.TextBox c15Txtbx;
        private System.Windows.Forms.TextBox c54Txtbx;
        private System.Windows.Forms.TextBox c53Txtbx;
        private System.Windows.Forms.TextBox c52Txtbx;
        private System.Windows.Forms.TextBox c51Txtbx;
        private System.Windows.Forms.TextBox c33Txtbx;
        private System.Windows.Forms.TextBox c12Txtbx;
        private System.Windows.Forms.TextBox c14Txtbx;
        private System.Windows.Forms.TextBox c11Txtbx;
        private System.Windows.Forms.TextBox c34Txtbx;
        private System.Windows.Forms.TextBox c13Txtbx;
        private System.Windows.Forms.TextBox c41Txtbx;
        private System.Windows.Forms.TextBox c32Txtbx;
        private System.Windows.Forms.TextBox c42Txtbx;
        private System.Windows.Forms.TextBox c21Txtbx;
        private System.Windows.Forms.TextBox c43Txtbx;
        private System.Windows.Forms.TextBox c31Txtbx;
        private System.Windows.Forms.TextBox c44Txtbx;
        private System.Windows.Forms.TextBox c22Txtbx;
        private System.Windows.Forms.TextBox c24Txtbx;
        private System.Windows.Forms.TextBox c23Txtbx;
        private System.Windows.Forms.Label OperacionLbl;
        private System.Windows.Forms.Label TamañoLbl;
        private System.Windows.Forms.ComboBox OperacionCmBx;
        private System.Windows.Forms.ComboBox TamañoCmBx;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox a55Txtbx;
        private System.Windows.Forms.TextBox a25Txtbx;
        private System.Windows.Forms.TextBox a35Txtbx;
        private System.Windows.Forms.TextBox a45Txtbx;
        private System.Windows.Forms.TextBox a15Txtbx;
        private System.Windows.Forms.TextBox a54Txtbx;
        private System.Windows.Forms.TextBox a53Txtbx;
        private System.Windows.Forms.TextBox a52Txtbx;
        private System.Windows.Forms.TextBox a51Txtbx;
        private System.Windows.Forms.TextBox a33Txtbx;
        private System.Windows.Forms.TextBox a12Txtbx;
        private System.Windows.Forms.TextBox a14Txtbx;
        private System.Windows.Forms.TextBox a11Txtbx;
        private System.Windows.Forms.TextBox a34Txtbx;
        private System.Windows.Forms.TextBox a13Txtbx;
        private System.Windows.Forms.TextBox a41Txtbx;
        private System.Windows.Forms.TextBox a32Txtbx;
        private System.Windows.Forms.TextBox a42Txtbx;
        private System.Windows.Forms.TextBox a21Txtbx;
        private System.Windows.Forms.TextBox a43Txtbx;
        private System.Windows.Forms.TextBox a31Txtbx;
        private System.Windows.Forms.TextBox a44Txtbx;
        private System.Windows.Forms.TextBox a22Txtbx;
        private System.Windows.Forms.TextBox a24Txtbx;
        private System.Windows.Forms.TextBox a23Txtbx;
        private System.Windows.Forms.GroupBox MetodosGrpBox;
        private System.Windows.Forms.Label X2Lbl;
        private System.Windows.Forms.Label X3Lbl;
        private System.Windows.Forms.Label X1Lbl;
        private System.Windows.Forms.TextBox CoeficienteX2R1TxtBOx;
        private System.Windows.Forms.TextBox CoeficienteX3R1TxtBOx;
        private System.Windows.Forms.TextBox CoeficienteX1R1TxtBOx;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox C3TxtBox;
        private System.Windows.Forms.TextBox C2TxtBox;
        private System.Windows.Forms.TextBox C1TxtBox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox CoeficienteX2R3TxtBOx;
        private System.Windows.Forms.TextBox CoeficienteX3R3TxtBOx;
        private System.Windows.Forms.TextBox CoeficienteX1R3TxtBOx;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox CoeficienteX2R2TxtBOx;
        private System.Windows.Forms.TextBox CoeficienteX3R2TxtBOx;
        private System.Windows.Forms.TextBox CoeficienteX1R2TxtBOx;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label C1Lbl;
        private System.Windows.Forms.Button MetodosCalcularBtt;
        private System.Windows.Forms.GroupBox MatrizAGrpBox;
        private System.Windows.Forms.GroupBox MatrizBGrpBox;
        private System.Windows.Forms.GroupBox MatrizCGrpBox;
        private System.Windows.Forms.TextBox b55Txtbx;
        private System.Windows.Forms.TextBox b25Txtbx;
        private System.Windows.Forms.TextBox b35Txtbx;
        private System.Windows.Forms.TextBox b45Txtbx;
        private System.Windows.Forms.TextBox b15Txtbx;
        private System.Windows.Forms.TextBox b54Txtbx;
        private System.Windows.Forms.TextBox b53Txtbx;
        private System.Windows.Forms.TextBox b52Txtbx;
        private System.Windows.Forms.TextBox b51Txtbx;
        private System.Windows.Forms.TextBox b33Txtbx;
        private System.Windows.Forms.TextBox b12Txtbx;
        private System.Windows.Forms.TextBox b14Txtbx;
        private System.Windows.Forms.TextBox b11Txtbx;
        private System.Windows.Forms.TextBox b34Txtbx;
        private System.Windows.Forms.TextBox b13Txtbx;
        private System.Windows.Forms.TextBox b41Txtbx;
        private System.Windows.Forms.TextBox b32Txtbx;
        private System.Windows.Forms.TextBox b42Txtbx;
        private System.Windows.Forms.TextBox b21Txtbx;
        private System.Windows.Forms.TextBox b43Txtbx;
        private System.Windows.Forms.TextBox b31Txtbx;
        private System.Windows.Forms.TextBox b44Txtbx;
        private System.Windows.Forms.TextBox b22Txtbx;
        private System.Windows.Forms.TextBox b24Txtbx;
        private System.Windows.Forms.TextBox b23Txtbx;
        private System.Windows.Forms.Label label22;
    }
}


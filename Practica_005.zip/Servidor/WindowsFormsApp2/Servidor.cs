﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Net.Sockets;

namespace WindowsFormsApp2
{
    public partial class Servidor : UserControl
    {
        public Servidor()
        {
            InitializeComponent();
        }

        private void SendBtt_Click(object sender, EventArgs e)
        {
            TcpListener serverSocket = new TcpListener(8888);
            int requestCount = 0;
            TcpClient clientSocket = default(TcpClient);
            serverSocket.Start();
            //Console.WriteLine("The Server is listening...");

            requestCount = 0;

            while ((true))
            {
                clientSocket = serverSocket.AcceptTcpClient();
                //Console.WriteLine(" >> Client connected...");

                try
                {


                    requestCount = requestCount + 1;
                    NetworkStream networkStream = clientSocket.GetStream();
                    byte[] bytesFrom = new byte[80];
                    networkStream.Read(bytesFrom, 0, 50);//(int)clientSocket.ReceiveBufferSize);
                    string dataFromClient = System.Text.Encoding.ASCII.GetString(bytesFrom);
                    dataFromClient = dataFromClient.Substring(0, dataFromClient.IndexOf("$"));
                    //Console.WriteLine(" >> Data from client - " + dataFromClient);

                    string serverResponse = "Last Message from client: " + dataFromClient + "$";
                    Byte[] sendBytes = Encoding.ASCII.GetBytes(serverResponse);
                    networkStream.Write(sendBytes, 0, sendBytes.Length);
                    networkStream.Flush();
                    Console.WriteLine(" >> " + serverResponse);

                    //Console.WriteLine("Reading file...");
                    byte[] fileBytes = new byte[10];
                    networkStream.Read(fileBytes, 0, 10);
                    using (Stream file = File.OpenWrite(@"OtroArchivo.txt"))
                    {
                        file.Write(fileBytes, 0, fileBytes.Length);
                        file.Close();
                    }

                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.ToString());
                    break;
                }
            }

            clientSocket.Close();
            serverSocket.Stop();
        }
    }
}

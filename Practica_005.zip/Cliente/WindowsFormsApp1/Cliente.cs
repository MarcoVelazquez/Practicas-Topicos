﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.Sockets;
using System.IO;

namespace WindowsFormsApp1
{
    public partial class Cliente : UserControl
    {
        public Cliente()
        {
            InitializeComponent();
        }
        //En esta variable se guarda la dirección ip del servidor donde se conectará el cliente
        string ipDirection,direccion_Archivo;
        

       

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void SendBtt_Click(object sender, EventArgs e)
        {
            System.Net.Sockets.TcpClient clientSocket = new System.Net.Sockets.TcpClient();
            SendBtt.Text = "Enviando...";
            clientSocket.Connect(ipDirection, 8888);
            //Console.WriteLine("Connected to server...");
            


            NetworkStream serverStream = clientSocket.GetStream();
            byte[] outStream = System.Text.Encoding.ASCII.GetBytes("Hello $");
            serverStream.Write(outStream, 0, outStream.Length);
            serverStream.Flush();

            byte[] inStream = new byte[10025];
            serverStream.Read(inStream, 0, 50);//(int)clientSocket.ReceiveBufferSize);
            string returndata = System.Text.Encoding.ASCII.GetString(inStream);
            Console.WriteLine(returndata.Substring(0, returndata.IndexOf("$")));

            FileStream readStream = File.OpenRead(direccion_Archivo);
            byte[] fileBytes = new byte[readStream.Length];

            readStream.Read(fileBytes, 0, fileBytes.Length);

            //Console.WriteLine("Sending file..." + fileBytes.Length);
            serverStream.Write(fileBytes, 0, fileBytes.Length);
            serverStream.Flush();
        }

        private void DireccionBtt_TextChanged(object sender, EventArgs e)
        {
            ipDirection =  DireccionBtt.Text;
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            direccion_Archivo = textBox2.Text;
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}

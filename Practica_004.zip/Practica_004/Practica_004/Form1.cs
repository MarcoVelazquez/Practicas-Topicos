﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Practica_004
{
    public partial class Form1 : Form
    {
        
        public Form1()
        {
            InitializeComponent();
            //Timer timer1 = new Timer();
            //timer1.Stop();
            timer1.Tick += timer1_Tick;
            timer1.Start();
            X = Y = 90;
            
        }

        public enum Direction { Up, Down, Left, Right };

        public int X, Y, FC=0, N, M;
        Direction dir = Direction.Right;

        private void timer1_Tick(object sender, EventArgs e)
        {
            switch (dir)
            {
                case Direction.Down:
                    Y += 10;
                    if (Y > pictureBox1.Height)
                        Y = 0;
                    break;
                case Direction.Up:
                    if (Y < 0)
                        Y = pictureBox1.Height;
                    Y -= 10;
                    break;
                case Direction.Left:
                    X -= 10;
                    if (X < 0)
                        X = pictureBox1.Width;
                    break;
                case Direction.Right:
                    X += 10;
                    if (X > pictureBox1.Width)
                        X = 0;
                    break;
            }

            pictureBox1.Invalidate();
        }
        private void pictureBox1_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.FillPie(Brushes.Yellow, X, Y, 30, 30, 45, 270);
            if (FC == 0)
            {
                FC=1;
                Random r = new Random();
                N = r.Next(0, 20);
                M = r.Next(0, 12);
            }
            generateFood(g, N, M);

            //pictureBox1.Invalidate();
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.Left:
                    if (dir != Direction.Right)
                        dir = Direction.Left;
                    break;
                case Keys.Right:
                    if (dir != Direction.Left)
                        dir = Direction.Right;
                    break;
                case Keys.Up:
                    if (dir != Direction.Down)
                        dir = Direction.Up;
                    break;
                case Keys.Down:
                    if (dir != Direction.Up)
                        dir = Direction.Down;
                    break;
            }
            //pictureBox1.Invalidate();
        }

        void generateFood(Graphics g, int N, int M)
        {
            //Random r = new Random();
            g.FillEllipse(Brushes.Red, N * 30, M * 30, 30, 30);
        }

    }
}
